//
//  ViewController.swift
//  PianoTiles
//
//  Created by admin on 31/10/2018.
//  Copyright © 2018 admin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
    @IBOutlet weak var loop: UIButton!
    @IBOutlet weak var star: UIButton!
    @IBOutlet weak var share: UIButton!
    
    var buttonsAreOn = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func moreButton(_ sender: UIButton) {
        if buttonsAreOn {
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
                self.hideButtons()
            }, completion: nil)
        } else {
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
                self.showButtons()
            }, completion: nil)
        }
        buttonsAreOn = !buttonsAreOn
    }
    
    private func hideButtons(){
        loop.center = CGPoint(x: -20, y: loop.center.y)
        star.center = CGPoint(x: -20, y: star.center.y)
        share.center = CGPoint(x: -20, y: share.center.y)
    }
    private func showButtons(){
        loop.center = CGPoint(x: 140, y: loop.center.y)
        star.center = CGPoint(x: 240, y: star.center.y)
        share.center = CGPoint(x: 340, y: share.center.y)
    }
    // Afficher le contenu de jeu
    @IBAction func AfficherContenuJeuBouton(_ sender: UIButton) {
        print("Bouton presser ")
        self.performSegue(withIdentifier: "SecondViewSegue", sender: self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

