//
//  ContenuJeu.swift
//  PianoTiles
//
//  Created by admin on 31/10/2018.
//  Copyright © 2018 admin. All rights reserved.
//

import UIKit

class ContenuJeu: UIViewController {

    @IBAction func boutonRetour(_ sender: Any) {
        print("bouton retour")
        self.performSegue(withIdentifier: "HomeSegue", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
